setwd("C:\\Users\\IT24102466\\Desktop\\IT24102466 Lab 4")


branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

print("=== VARIABLE TYPES AND SCALES ===")
print("Branch: Categorical, Nominal scale")
print("Sales_X1:  Discrete numerical, Ratio scale")
print("Advertising_X2: Continuous numerical, Ratio scale")
print("Years_X3: Continuous numerical, Ratio scale")



print("=== BOXPLOT FOR SALES ===")
boxplot(branch_data$Sales_X1, 
        main = "Boxplot of Sales", 
        ylab = "Sales (X1)",
        col = "lightblue")


print("=== FIVE NUMBER SUMMARY AND IQR FOR ADVERTISING ===")
advertising_summary <- summary(branch_data$Advertising_X2)
iqr_value <- IQR(branch_data$Advertising_X2)

print("Five Number Summary:")
print(advertising_summary)

print(paste("IQR for Advertising:", iqr_value))

# Detailed calculation
q1 <- quantile(branch_data$Advertising_X2, 0.25)
q3 <- quantile(branch_data$Advertising_X2, 0.75)
print(paste("Q1 (25th percentile):", q1))
print(paste("Q3 (75th percentile):", q3))
print(paste("IQR (Q3 - Q1):", q3 - q1))



print("=== OUTLIER DETECTION FUNCTION ===")
find_outliers <- function(data_vector) {
  q1 <- quantile(data_vector, 0.25, na.rm = TRUE)
  q3 <- quantile(data_vector, 0.75, na.rm = TRUE)
  iqr <- q3 - q1
  
  lower_bound <- q1 - 1.5 * iqr
  upper_bound <- q3 + 1.5 * iqr
  
  outliers <- data_vector[data_vector < lower_bound | data_vector > upper_bound]
  
  return(list(
    outliers = outliers,
    lower_bound = lower_bound,
    upper_bound = upper_bound
  ))
}

years_outliers <- find_outliers(branch_data$Years_X3)

print(paste("Lower bound:", years_outliers$lower_bound))
print(paste("Upper bound:", years_outliers$upper_bound))

if (length(years_outliers$outliers) > 0) {
  print(paste("Outliers found:", years_outliers$outliers))
} else {
  print("No outliers found in Years variable")
}